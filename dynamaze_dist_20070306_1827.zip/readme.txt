
Readme for DynaMaze by Kurt W Dekker for PLBM Games

Updated March 6, 2007 - Release v1.0

http://www.plbm.com

Another test python/pygame project by Kurt Dekker/PLBM Games

NOTE: This game has been tested with a Logitech dual analog
USB joystick. I highly recommend a dual-joystick control so
that you can move and fire 100% independently. You can use a
keyboard but it is a LOT harder to do.

You're in a Dynamic Maze! Yes, this maze is ever-changing.
You won't see it change, but you can be sure that if you try
to remember how some part of the maze is, you will find that
when you return to it, it will be quite different.

Rove around and kill enemies until you locate the secret base,
which will have a direction arrow so you can drive to it.

Destroy the secret base and move onto the next level.

Once they realize you have spotted their base, the enemies
get more and more aggressive, so be quick in destroying the
base or else things get dicey.

Use a dual-analog-axis joystick, or else just the keyboard.

If you get stuck, you can actually blast your way through
maze walls, if you spend enough time and ammo, but you should
never really need to do this.
